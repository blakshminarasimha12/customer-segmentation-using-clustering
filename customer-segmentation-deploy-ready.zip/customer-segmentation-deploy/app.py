import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

st.set_page_config(page_title="Customer Segmentation", page_icon="📊", layout="wide")
st.title("📊 Customer Segmentation using K-Means Clustering")
st.write("Interactive customer segmentation based on age, income, spending score, and purchase frequency.")

@st.cache_data
def demo_data(n=300, seed=42):
    rng = np.random.default_rng(seed)
    age = rng.integers(18, 61, n)
    gender = rng.choice(["Male", "Female"], n)
    income = np.clip(rng.normal(60000, 22000, n), 15000, 150000).round().astype(int)
    spending = np.clip(48 + 0.00025*(income-60000) - 0.35*(age-35) + rng.normal(0,15,n), 1, 100).round().astype(int)
    frequency = np.clip(3 + spending/12 + rng.normal(0,2.5,n), 1, 30).round().astype(int)
    return pd.DataFrame({
        "Customer_ID": np.arange(1001,1001+n), "Age": age, "Gender": gender,
        "Annual_Income": income, "Spending_Score": spending,
        "Purchase_Frequency": frequency
    })

uploaded = st.sidebar.file_uploader("Upload customer CSV", type=["csv"])
df = pd.read_csv(uploaded) if uploaded else demo_data()

required = ["Customer_ID","Age","Gender","Annual_Income","Spending_Score","Purchase_Frequency"]
missing = [c for c in required if c not in df.columns]
if missing:
    st.error("Missing required columns: " + ", ".join(missing))
    st.stop()

df = df.drop_duplicates().copy()
for c in ["Age","Annual_Income","Spending_Score","Purchase_Frequency"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df = df.dropna(subset=["Age","Annual_Income","Spending_Score","Purchase_Frequency"])

features = ["Age","Annual_Income","Spending_Score","Purchase_Frequency"]
scaled = StandardScaler().fit_transform(df[features])
k = st.sidebar.slider("Number of clusters (K)", 2, 8, 4)
model = KMeans(n_clusters=k, random_state=42, n_init=10)
df["Cluster"] = model.fit_predict(scaled) + 1

t1,t2,t3,t4 = st.tabs(["Overview","Clusters","Visualization","Data"])

with t1:
    st.subheader("Project Overview")
    a,b,c,d = st.columns(4)
    a.metric("Customers", len(df))
    b.metric("Clusters", k)
    c.metric("Avg Income", f"₹{df['Annual_Income'].mean():,.0f}")
    d.metric("Avg Spending", f"{df['Spending_Score'].mean():.1f}")
    st.info("K-Means groups customers with similar characteristics to support targeted marketing and data-driven decisions.")

with t2:
    st.subheader("Cluster Summary")
    summary = df.groupby("Cluster").agg({
        "Age":"mean","Annual_Income":"mean","Spending_Score":"mean",
        "Purchase_Frequency":"mean","Customer_ID":"count"
    }).round(2).rename(columns={"Customer_ID":"Customer_Count"})
    st.dataframe(summary, use_container_width=True)

with t3:
    fig, ax = plt.subplots(figsize=(10,6))
    for cluster in sorted(df["Cluster"].unique()):
        s = df[df["Cluster"] == cluster]
        ax.scatter(s["Annual_Income"], s["Spending_Score"], s=60, label=f"Cluster {cluster}")
    ax.set_xlabel("Annual Income (₹)")
    ax.set_ylabel("Spending Score")
    ax.set_title("Customer Segmentation: Income vs Spending Score")
    ax.legend()
    st.pyplot(fig)

with t4:
    st.dataframe(df, use_container_width=True)
    st.download_button("Download Segmented CSV", df.to_csv(index=False).encode(), "segmented_customers.csv", "text/csv")
